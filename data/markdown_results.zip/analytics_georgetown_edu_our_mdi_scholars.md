# Our MDI Scholars

DSAN students have continuously been selected each semester to be MDI Scholars. They engage in interdisciplinary data science and public policy research across Georgetown.

## Current DSAN MDI Scholars

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2025/02/Jorge-Bris-Moreno-scaled-1.jpeg)

Jorge Bris Moreno

MS ’25

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2025/02/Stacy-Che-scaled-1.jpeg)

Stacy Che

MS ’26

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2025/02/BinhuiChenMDIScholar.jpeg)

Binhui Chen

MS ’25

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2025/02/Hannah-Kim-scaled-1.jpeg)

Hannah Kim

MS ’25

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2025/02/Billy.jpeg)

Billy McGloin

MS ’25

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2025/02/Rich.jpeg)

Rich Pihlstrom

MS ’25

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2025/02/Zining-Cathy-Wang-scaled-1.jpeg)

Zining (Cathy) Wang

MS ’25

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2025/02/Quan.jpeg)

Quan Yuan

MS ’25