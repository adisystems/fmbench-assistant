# Employer Partnerships

The MS Data Science and Analytics Program (DSAN) invites organizations to connect with us. Partners will have the opportunity to market, recruit, interview on-campus/online, and engage with DSAN students and alumni.

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2024/02/cdd20-iNVY0hQvgCE-unsplash-scaled.jpg)

## Meet the Next Generation of Data Scientists

Fill out your information to access our Company Resume Books

[Resume Book Request Form](https://forms.gle/kBMe5kaJ4LsdZo9m7)