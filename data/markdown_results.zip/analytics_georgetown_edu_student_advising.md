# Student Advising

The Data Science and Analytics (DSAN) program provides students with an administrative team to assist them in navigating their journey through the program.

Please consult with the appropriate person on advising topics per the chart below.

| Dr. Purna Gamage – Program Director | Heather Connor – Director of Student Services | Ashley Stowe – Outreach and Engagement Manager |
| --- | --- | --- |
| Course Advising | Registration Issues | Program Sponsored Events |
| Academic Difficulties | Billing | Student Life |
| Grades/GPA | Financial Aid/Scholarships | Professional Development Center |
| Internships/Employment | Graduation | Alumni Mentorship Program |
| Career Path | Leave of Absence Petitions | DSAN Social Committee |
| Applying to PhD Programs | Transfer Credit Petitions |  |
|  | Teaching Assistantships |  |
|  | Research Assistantships |  |
|  | International Student Support |  |
|  | Academic Integrity |  |
|  | Mentorship Program |  |
|  | Professional Development Center |  |