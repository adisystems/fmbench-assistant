# News

## DSAN News

[News Stories](https://analytics.georgetown.edu/category/news-story/)

![Healy Hall's bell tower framed by two green trees](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2023/10/20191004_FallCampusSunrise-9946-e1736449076712.jpg)

News Story

[DSAN Students in Our Climate Change Course Evaluate New ClimateGPT, Built by Erasmus.AI](https://analytics.georgetown.edu/news-story/dsan-students-in-our-climate-change-course-evaluate-new-climategpt-built-by-erasmus-ai/)

January 9, 2025

News Story

[Students Explored a Diversity of Topics at the DSAN Fall Poster Sessions](https://analytics.georgetown.edu/news-story/students-explored-a-diversity-of-topics-at-the-dsan-fall-poster-sessions/)

December 19, 2024

News Story

[Student Perspective: DSAN Students Tackle Parking Optimization in Arlington](https://analytics.georgetown.edu/news-story/student-perspective-dsan-students-tackle-parking-optimization-in-arlington/)

December 2, 2024

![Capitol Building dom in Washinton DC](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2025/03/180419_CapitolHillDC-2814.jpg)

Announcements, News Story

[Georgetown DSAN Offers Scholarships and Extended Deadlines for Federal Workforce](https://analytics.georgetown.edu/news-story/georgetown-dsan-offers-scholarships-and-extended-deadlines-for-federal-workforce/)

Georgetown DSAN values the impactful work of those in public service, and we recognize that federal government reductions in the workforce and other governmental shifts have impacted many in the DMV…

March 24, 2025