# Category: News Story

54 Articles

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2025/03/180419_CapitolHillDC-2814-1024x683.jpg)

AnnouncementsNews Story

## [Georgetown DSAN Offers Scholarships and Extended Deadlines for Federal Workforce](https://analytics.georgetown.edu/news-story/georgetown-dsan-offers-scholarships-and-extended-deadlines-for-federal-workforce/)

Georgetown DSAN values the impactful work of those in public service, and we recognize that federal government reductions in the workforce and other governmental shifts have…

March 24, 2025

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2023/10/20191004_FallCampusSunrise-9946-1024x683.jpg)

News Story

## [DSAN Students in Our Climate Change Course Evaluate New ClimateGPT, Built by Erasmus.AI](https://analytics.georgetown.edu/news-story/dsan-students-in-our-climate-change-course-evaluate-new-climategpt-built-by-erasmus-ai/)

ClimateGPT, built by Erasmus.AI is an AI-powered platform designed to assist users in understanding climate change and its impacts. In a data science class at Georgetown…

January 9, 2025

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2024/12/1-3-1024x1024.png)

News Story

## [Students Explored a Diversity of Topics at the DSAN Fall Poster Sessions](https://analytics.georgetown.edu/news-story/students-explored-a-diversity-of-topics-at-the-dsan-fall-poster-sessions/)

Poster sessions are an important part of the student experience within the MS Data Science & Analytics program. Not only do they allow students to explore a wide range of…

December 19, 2024

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2024/12/Code-the-Curb-1-scaled-e1733176548887-1024x502.jpg)

News Story

## [Student Perspective: DSAN Students Tackle Parking Optimization in Arlington](https://analytics.georgetown.edu/news-story/student-perspective-dsan-students-tackle-parking-optimization-in-arlington/)

Two of our first-year DSAN students participated in the Code the Curb hackathon in Arlington last month. Read about their!…

December 2, 2024

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2024/11/Binhui-Chen.png)

News Story

## [Binhui Chen (MS ‘25) Among Top 10 Graduate Students Presenting at ‘25 NCME Conference](https://analytics.georgetown.edu/news-story/binhui-chen-ms-25-among-top-10-graduate-students-presenting-at-25-ncme-conference/)

We are excited to share that Binhui Chen’s (MS’25) paper, “Advancing Sequence Clustering with Time-Wrapping Distance Measurement,” has been accepted by the…

November 19, 2024

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2024/10/12-1024x536.png)

News Story

## [DSAN Director, Dr. Purna Gamage, honored at GU Fall Faculty Convocation](https://analytics.georgetown.edu/news-story/dsan-director-dr-purna-gamage-honored-at-gu-fall-faculty-convocation/)

Georgetown University holds a Fall Faculty Convocation Ceremony to recognize and honor faculty members recently promoted or receiving tenure. Dr. Gamage received a promotion and…

October 31, 2024

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2024/10/1-2-e1729702039163-1024x733.png)

Blog ByteNews Story

## [Unlocking Your Potential: Looking Back on DSAN’s Professional Development Day](https://analytics.georgetown.edu/news-story/unlocking-your-potential-looking-back-on-dsans-professional-development-day/)

DSAN Student Viviana Luccioli shares her perspective on our Professional Development!…

October 23, 2024

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2024/10/Yiming-Chen-768x1024.jpeg)

News Story

## [Yiming Chen, MS ’24, Appointed Inaugural Research Associate for AIMD Lab at DSAN](https://analytics.georgetown.edu/news-story/yiming-chen-ms-24-appointed-inaugural-research-associate-for-aimd-lab-at-dsan/)

We are excited to announce that DSAN Alumna Yiming Chen will be the very first Research Associate for Dr. Britt He’s AI Measurement and Data Science (AIMD) Lab in the Data…

October 3, 2024

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2024/05/advanced-data-vis-crop-1476342401-1024x427.jpg)

News Story

## [DSAN partners with SCS for a Data Visualization Certificate Course](https://analytics.georgetown.edu/news-story/dsan-partners-with-scs-for-data-visualization-certificate-course/)

We are excited to announce that the DSAN program is partnering to offer a non-credit professional development Advanced Data Visualization Certificate.

This 12-week program will…

May 28, 2024

![](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2024/05/Student-Profile-Header-1024x536.png)

News StoryStudent Profile

## [Raunak Advani](https://analytics.georgetown.edu/announcements/student-profile/raunak-advani/)

As an accelerated student, why did you choose the DSAN program?  I first discovered the DSAN program while I was completing the junior year of my undergraduate studies at…

May 6, 2024