![Dr. Gamage and Provost Robert Groves](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2024/10/12.png)

[News Story](https://analytics.georgetown.edu/category/news-story/)

# DSAN Director, Dr. Purna Gamage, honored at GU Fall Faculty Convocation

Georgetown University holds a Fall Faculty Convocation Ceremony to recognize and honor faculty members recently promoted or receiving tenure. Dr. Gamage received a promotion and is now an Associate Teaching Professor. She has been the Director of the M.S. Data Science and Analytics program for over two years.

![Dr. Gamage and Provost Robert Groves](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2024/10/12.png)

![Provost Robert Groves shakes Dr. Gamage's hand during the ceremony](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2024/10/13.png)

![Dr. Gamage and DSAN Director of Student Services, Heather Connor](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2024/10/15.png)

![Dr. Gamage with DSAN faculty member Dr. Jeff Jacobs](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2024/10/14.png)

![Dr. Gamage and DSAN faculty member Dr. Britt He](https://analytics.georgetown.edu/wp-content/uploads/sites/452/2024/10/16.png)

We congratulate Dr. Gamage and are so excited to celebrate this great achievement with her!

[iframe](https://td.doubleclick.net/td/ga/rul?tid=G-PMZB7WHYPX&gacid=1112649076.1743169522&gtm=45je53q1h1v9104793239z877583222za200zb77583222&dma=0&gcd=13l3l3l3l1l1&npa=0&pscdl=noapi&aip=1&fledge=1&frm=0&tag_exp=102482433~102788824~102803279~102813109~102887800~102926062~102964103~102975948&z=212811878)[iframe](https://td.doubleclick.net/td/ga/rul?tid=G-BSC82Y20RS&gacid=1112649076.1743169522&gtm=45je53q1h1v9104488821z877583222za200zb77583222&dma=0&gcd=13l3l3l3l1l1&npa=0&pscdl=noapi&aip=1&fledge=1&frm=0&tag_exp=102482433~102509683~102788824~102803279~102813109~102887800~102926062&z=619139961)[iframe](https://14950278.fls.doubleclick.net/activityi;src=14950278;type=anlytcal;cat=anlytcal;ord=1410756430094;npa=0;auiddc=1838436760.1743169522;ps=1;pcor=743158723;uaa=x86;uab=64;uafvl=Chromium%3B134.0.6998.165%7CNot%253AA-Brand%3B24.0.0.0%7CGoogle%2520Chrome%3B134.0.6998.165;uamb=0;uam=;uap=Linux%20x86_64;uapv=6.6.72;uaw=0;pscdl=noapi;frm=0;_tu=KlA;gtm=45fe53q1h1v9198042436z877583222za201zb9104488821;gcd=13l3l3l3l1l1;dma=0;dc_fmt=1;tag_exp=102482433~102788824~102803279~102813109~102887800~102926062~102975948;epver=2;~oref=https%3A%2F%2Fanalytics.georgetown.edu%2Fnews-story%2Fdsan-director-dr-purna-gamage-honored-at-gu-fall-faculty-convocation%2F?)[iframe](https://td.doubleclick.net/td/fls/rul/activityi;fledge=1;src=14950278;type=anlytcal;cat=anlytcal;ord=1410756430094;npa=0;auiddc=1838436760.1743169522;ps=1;pcor=743158723;uaa=x86;uab=64;uafvl=Chromium%3B134.0.6998.165%7CNot%253AA-Brand%3B24.0.0.0%7CGoogle%2520Chrome%3B134.0.6998.165;uamb=0;uam=;uap=Linux%20x86_64;uapv=6.6.72;uaw=0;pscdl=noapi;frm=0;_tu=KlA;gtm=45fe53q1h1v9198042436z877583222za201zb9104488821;gcd=13l3l3l3l1l1;dma=0;dc_fmt=9;tag_exp=102482433~102788824~102803279~102813109~102887800~102926062~102975948;epver=2;~oref=https%3A%2F%2Fanalytics.georgetown.edu%2Fnews-story%2Fdsan-director-dr-purna-gamage-honored-at-gu-fall-faculty-convocation%2F?)[iframe](https://insight.adsrvr.org/track/up?adv=tz1xvy0&ref=https%3A%2F%2Fanalytics.georgetown.edu%2Fnews-story%2Fdsan-director-dr-purna-gamage-honored-at-gu-fall-faculty-convocation%2F&upid=a8id7gz&upv=1.1.0&paapi=1)